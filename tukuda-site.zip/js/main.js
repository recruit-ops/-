(function(){
  var btn = document.getElementById('navToggle');
  var nav = document.getElementById('siteNav');
  if(btn && nav){
    btn.addEventListener('click', function(){
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.textContent = open ? '閉じる' : 'メニュー';
    });
    nav.addEventListener('click', function(e){
      if(e.target.tagName === 'A'){
        nav.classList.remove('open');
        btn.setAttribute('aria-expanded','false');
        btn.textContent = 'メニュー';
      }
    });
  }

  var items = document.querySelectorAll('.reveal');
  if(!('IntersectionObserver' in window)){
    Array.prototype.forEach.call(items, function(el){ el.classList.add('in'); });
    return;
  }
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); }
    });
  }, {threshold:.15, rootMargin:'0px 0px -40px 0px'});
  Array.prototype.forEach.call(items, function(el, i){
    el.style.transitionDelay = (i % 3 * 80) + 'ms';
    io.observe(el);
  });
})();
